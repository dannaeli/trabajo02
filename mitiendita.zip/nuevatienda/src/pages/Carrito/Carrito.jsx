import './Carrito.css'
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import imgPollo from '../../assets/pollo.jpg';
import imgLeche from '../../assets/leche.webp';  
import imgHuevo from '../../assets/huevo.jpg';
import imgGarbanzo from '../../assets/garbanzo.jpg';
import Header from '../../components/Header/Header';
import Aside from '../../components/Aside/Aside';
import ResumenLectura from '../../components/ResumenLectura/ResumenLectura';

const initialProducts = [
    {
        id: 1,
        name: "Pollo entero fresco con menudencia",
        description: "Presentación 2.2 kg aprox",
        price: 20.65,
        quantity: 2,
        image: imgPollo,
        selected: true
    },
    {
        id: 2,
        name: "Leche gloria",
        description: "Presentación 6 unidades",
        price: 22.65,
        quantity: 1,
        image: imgLeche,
        selected: true
    },
    {
        id: 3,
        name: "Huevos Pardos LA CALERA Paquete 30un",
        description: "Presentación 30 unidades",
        price: 22.00,
        quantity: 2,
        image: imgHuevo,
        selected: true
    },
    {
        id: 4,
        name: "Garbanzo costeño",
        description: "Presentación 1kg aprox",
        price: 10.65,
        quantity: 2,
        image: imgGarbanzo,
        selected: true
    }
];

const Carrito = () => {
    const navigate = useNavigate();
    const [productos, setProductos] = useState(initialProducts);

    useEffect(() => {
        try {
            const savedCart = localStorage.getItem('cart');
            if (savedCart) {
                const parsedCart = JSON.parse(savedCart);
                if (Array.isArray(parsedCart) && parsedCart.length > 0) {
                    setProductos(parsedCart);
                } else {
                    setProductos(initialProducts);
                    localStorage.setItem('cart', JSON.stringify(initialProducts));
                }
            } else {
                setProductos(initialProducts);
                localStorage.setItem('cart', JSON.stringify(initialProducts));
            }
        } catch (error) {
            console.error('Error loading cart:', error);
            setProductos(initialProducts);
            localStorage.setItem('cart', JSON.stringify(initialProducts));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('cart', JSON.stringify(productos));
    }, [productos]);

    const cambiarSeleccion = (id) => {
        setProductos(productos.map(producto => 
            producto.id === id 
                ? {...producto, selected: !producto.selected}
                : producto
        ));
    };

    const cambiarCantidad = (id, incrementar) => {
        setProductos(productos.map(producto => {
            if (producto.id === id) {
                const nuevaCantidad = incrementar 
                    ? producto.quantity + 1 
                    : Math.max(1, producto.quantity - 1);
                return {...producto, quantity: nuevaCantidad};
            }
            return producto;
        }));
    };

    const eliminarProducto = (id) => {
        setProductos(productos.filter(producto => producto.id !== id));
    };

    return (
        <>
            <Header />
            <div className="main-content">
                <Aside />
                <main className="carritoContainer">
                    <div className="productosSection">
                        <h2><strong>Carro</strong> ({productos.filter(p => p.selected).reduce((sum, p) => sum + p.quantity, 0)} productos)</h2>
                        <div className="cajaScroll">
                            {productos.map((producto) => (
                                <div className="productoItem" key={producto.id}>
                                    <input 
                                        type="checkbox" 
                                        checked={producto.selected} 
                                        onChange={() => cambiarSeleccion(producto.id)}
                                    />
                                    <img src={producto.image} alt={producto.name}/>
                                    <div className="infoItem">
                                        <h3>{producto.name}</h3>
                                        <p>{producto.description}</p>
                                        <p className="envio">Llega mañana</p>
                                        <div className="cantidadControl">
                                            <label>Cantidad:</label>
                                            <button onClick={() => cambiarCantidad(producto.id, false)}>-</button>
                                            <span>{producto.quantity}</span>
                                            <button onClick={() => cambiarCantidad(producto.id, true)}>+</button>
                                            <button className="eliminar" onClick={() => eliminarProducto(producto.id)}>🗑</button>
                                        </div>
                                    </div>
                                    <div className="precio">S/{(producto.price * producto.quantity).toFixed(2)}</div>
                                </div>
                            ))}
                        </div>
                    </div>
                    <ResumenLectura />
                </main>
            </div>
        </>
    );
};

export default Carrito;