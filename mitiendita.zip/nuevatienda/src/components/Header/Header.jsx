import imgLogo from '../../assets/logo.png';
import imgCarrito from '../../assets/carrito.png';
import imgUser from '../../assets/user.png';
import './Header.css';

const Header = () => {
    return (
        <header>
            <img src={imgLogo} className="logo" alt="Logo"/>
            <div className="contenedorBuscador">
                <input type="text" placeholder="Buscar un producto..." />
            </div>
            <div className="contenedorCarrito">
                <img src={imgCarrito} className="carrito" alt="Carrito"/>
                <div className="nombreCarrito">
                    <p><strong>Carrito</strong></p>
                    <p>S/.100.00</p>
                </div>
            </div>
            <div className="contenedorUser">
                <img src={imgUser} className="user" alt="Usuario"/>
                <div className="nombreUser">
                    <p><strong>Usuario</strong></p>
                    <p>cuenta</p>
                </div>
            </div>
        </header>
    )
}

export default Header