import './Aside.css';

const Aside = () => {
    return (
        <aside>
        <ul>
            <li><a href="#">Categorías</a></li>
            <li><a href="#">Productos</a></li>
            <li><a href="#">Nosotros</a></li>
        </ul>
        <div class="ofertas">
            <a href="#">OFERTAS👋</a>
        </div>
        </aside>
    )
}

export default Aside
