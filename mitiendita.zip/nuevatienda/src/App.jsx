import './App.css'

function App() {
  return (
    <div className="app">
      <h1>Bienvenido a la Tienda</h1>
    </div>
  )
}

export default App
